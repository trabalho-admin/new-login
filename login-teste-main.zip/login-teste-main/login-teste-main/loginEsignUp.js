"use strict";
/*
status: 50%, nao concluido
data: 22/11
descricao: neste arquivo contem codigos nessesariso para fazer validacao dos campos,
login e registro no localStorage do navegador do usuario.
modulos: os codigos aqui presentes dependem da classe user para funcionar corretamente
para integrar este codigo copie isto no header do site:  <script src="loginEsignUp.js" defer></script>
*/

const inputName = document.getElementById("inputName");//referencia ao input do nome do usuario
const inputPassword = document.getElementById("inputPassword");//referencia ao input da senha do usuario
const formBtn = document.getElementById("formButton");//referencia o botão do formularia
var x = false;
function validarUsuario(){
    /*
    status: concluido
    data: 22/11
    descricao: esta funcao verifica se os 2 campos input estao vazios se  estiverem
    exibe um alert senao ele retorna true indicando que foi validado com sucesso.
    */

    if (inputName.value == "") {
        //se o campo nome estiver vazio entao:
        alert("O campo nome não pode estar vazio.");
    } else if (inputPassword.value == "") {
        //se o campo senha estiver vazio entao:
        alert("O campo senha não pode estar vazio.");
    } else {
        //se os 2 input nao forem vazios entao:
        createUser(inputName.value, inputPassword.value)
        inputName.value = "";
        inputPassword.value = "";
    }

}

function verifica() {
    /*
    status: concluido
    data: 22/11
    descricao: esta funcao verifica se os 2 campos input estao vazios se  estiverem
    exibe um alert senao ele retorna true indicando que foi validado com sucesso.
    */
    if (inputName.value == "") {
        //se o campo nome estiver vazio entao:
        return false;
    } else if (inputPassword.value == "") {
        //se o campo senha estiver vazio entao:
        return false;

    } else {

        return true;
    }
}

function createUser(nome, senha) {
    /*
    status: concluido
    data: 22/11
    descricao: verifica se os campos estao vazios e se o usuario criado ja existe,
    se os inputs estiverem vazios e o usuario nao existir ele e criado no localStorage, senao e exibido um alert.
    modulos: classe user;
    */


if(x==true){
    if (
        verifica() == true &&
        localStorage.getItem("School_Game_User:" + nome) == null
    ) {
        /*descricao:verifica se os campos nao estao vazios e se o usuario ja existe no localStorage
            se sim da um alerta senao ele registra o usuario.
            */
        let user = new Usuario(nome, senha);

        localStorage.setItem(
            "School_Game_User:" + user.getNome,
            JSON.stringify(user)
        );
        console.log(user);
        console.log('kkkk');

    } else {
        alert(
            "Este usuário ja esta registrado!, não foi possivel registrar este usuário\n tente novamente."
        );
    }
}else{
    x=true
}

}

function getUser(username) {
    /*
    status: concluido
    data: 22/11
    descricao: verifica se os campos estao vazios e se o usuario existe, se sim entao
    ela acessa o local storage e retorna um objeto correspondente ao objeto correspondente ao username e password digitados
    */
    let key = "School_Game_User:" + username;
    if (verifica() == true && localStorage.getItem(key) != null) {
        /*descricao:verifica se os campos nao estao vazios e se o usuario existe no localStorage
        se sim ele retorna o objeto do usuario solicitado com base em seu username, senao ele da um alerta..
        */

        let user = JSON.parse(localStorage.getItem(key)); //acessa as informaçoes do usuario e as trasforma de objeto para string
        console.log(user);
        return user;
    } else {
        alert(
            "O  usuário solicitado não existe, verifique se os campos estão preenchidos corretamente."
        );
        return false;
    }
}

function deleteUser(username) {
    /*
    status: concluido
    data: 22/11
    descricao: verifica se os campos estao vazios e se o usuario existe se sim o deleta senao exibe um alerta.
    */
    if (verifica() == true && localStorage.getItem("School_Game_User:" + username) != null) {
        localStorage.removeItem("School_Game_User:" + username); //exclui o usuario solicitado
    } else {
        alert('Não e possivel excluir um usuario que não existe.')
    }
}

/*
adiciona o evento criar usuario ao botao do formulario
*/
formBtn.addEventListener('click',

validarUsuario()
        
    
    
);




/*

formBtn2.addEventListener("click", () => {

adiciona afuncao get user ao botao2 do formulario

getUser(inputName.value);
});

*/
