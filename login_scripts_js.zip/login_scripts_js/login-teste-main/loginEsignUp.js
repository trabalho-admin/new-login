"use strict"
/*
status: 50% concluido
o que alta: o restop do site estar pronto para fazer as funçoes de login
data: 22/11
descricao: neste arquivo contem codigos nessesariso para fazer validacao dos campos,
login e registro no localStorage do navegador do usuario.
modulos: os codigos aqui presentes dependem da classe user para funcionar corretamente
*/

/*
para integrar este codigo copie isto no header do site: <script src="user.js" defer></script> <script src="loginEsignUp.js" defer></script>
copie isto dentro da tag do botao: onclick="validarUsuario(inputName.value, inputPassword.value)"
copie isto dentro da tag do input do nome:> id="inputName"
copie isto dentro da tag do input da senha:> id="inputPassword"
*/
const inputName = document.getElementById("inputName"); //referencia ao input do nome do usuario
const inputPassword = document.getElementById("inputPassword"); //referencia ao input da senha do usuario
const formBtn = document.getElementById("formButton"); //referencia o botão do formularia
let key = "SCHOOL_GAME_USER:";

document.body.addEventListener("DOMContentLoaded", () => {
  /*
    status:concluido mas nao testado
    data: 24/11
    descricao: verifica se o navegador suporta o webStorage se nao suportar exibe um alert.
    */
  if (!typeof Storage !== "undefined") {
    alert(
      "Seu navegador não suporta o web storage\n pode ser que o site não funcione corretamente, para consertar isso\n por favor atualizae seu navegador."
    );
  }
});

function validarUsuario() {
  /*
    status: concluido
    data: 22/11
    descricao: esta funcao verifica se os 2 campos input estao vazios se  estiverem
    exibe um alert senao ele retorna true indicando que foi validado com sucesso.
    */

  if (inputName.value == "") {
    //se o campo nome estiver vazio entao:
    alert("O campo nome não pode estar vazio.");
  } else if (inputPassword.value == "") {
    //se o campo senha estiver vazio entao:
    alert("O campo senha não pode estar vazio.");
  } else {
    //se os 2 input nao forem vazios entao:
    createUser(
      inputName.value.toUpperCase(),
      inputPassword.value.toUpperCase()
    );
    inputName.value = "";
    inputPassword.value = "";
  }
}

function verifica() {
  /*
    status: concluido
    data: 24/11
    descricao: esta funcao verifica se os 2 campos input estao vazios se  estiverem
    exibe retorna false senao retorna true..
    */
  if (inputName.value == "") {
    //se o campo nome estiver vazio entao:
    return false;
  } else if (inputPassword.value == "") {
    //se o campo senha estiver vazio entao:
    return false;
  } else {
    return true;
  }
}

function createUser(nome, senha) {
  /*
    status: concluido
    data: 24/11
    descricao: verifica se os campos estao vazios e se o usuario criado ja existe,
    se os inputs estiverem vazios e o usuario nao existir ele e criado no localStorage, senao e exibido um alert.
    modulos: classe user;
    */

  if (verifica() == true && localStorage.getItem(key + nome) == null) {
    /*descricao:verifica se os campos nao estao vazios e se o usuario ja existe no localStorage
      se sim da um alerta senao ele registra o usuario.
    */
    let user = new Usuario(nome, senha);
    localStorage.setItem(key + user.getNome, JSON.stringify(user));
    console.log(user);
    user = null; //libera o espaço de memoria que a variavel esta ocupando
  } else {
    alert(
      "Este usuário ja esta registrado!, não foi possivel registrar este usuário\n tente novamente."
    );
  }
}

function getUser(username) {
  /*
    status: concluido
    data: 22/11
    descricao: verifica se os campos estao vazios e se o usuario existe, se sim entao
    ela acessa o local storage e retorna um objeto correspondente ao objeto correspondente ao username e password digitados
    */
  if (
    verifica() == true &&
    localStorage.getItem(key + username.toUpperCase()) != null
  ) {
    /*descricao:verifica se os campos nao estao vazios e se o usuario existe no localStorage
        se sim ele retorna o objeto do usuario solicitado com base em seu username, senao ele da um alerta..
        */

    let user = JSON.parse(localStorage.getItem(key + username.toUpperCase())); //acessa as informaçoes do usuario e as trasforma de objeto para string
    console.log(user);
    return user;
    user = null; //libera o espaço de memoria que a variavel esta ocupando
  } else {
    alert(
      "O  usuário solicitado não existe, verifique se os campos estão preenchidos corretamente."
    );
    return false;
  }
}

function deleteUser(username) {
  /*
    status: concluido
    data: 22/11
    descricao: verifica se os campos estao vazios e se o usuario existe se sim o deleta senao exibe um alerta.
    */
  if (
    verifica() == true &&
    localStorage.getItem(key + username.toUpperCase()) != null
  ) {
    localStorage.removeItem(key + username); //exclui o usuario solicitado
  } else {
    alert("Não e possivel excluir um usuario que não existe.");
  }
}

function debug() {
  /*
    status: concluido
    data: 24/11
    descricao: usado para depuracao deste codigo, em caso de erros use esta funcao para debugar.
    */
  console.log(inputName);
  console.log(inputPassword);
  console.log(formBtn);
  console.log(localStorage);
}
