class AdminDebug{
    /*
status: nao conluido e nao testado.
data: 24/11
descricao: esta clase tambem e usada para depuracao para encontrar possiveis
erros e comportamentos estranhos em um objeto de usuario.
modulo: nenhum
    */
    constructor(){

    }
    getUserAtributes(user){
        let userInfo = [user.getNome,
        user.getSenha, user.getXp, user.getNivel,
        user.getEstrelasColetadas
        ]

        let quizInfo =[ getQuizTopicoAtual,
        getQuizQuestaoAtual, getQuizTopicosCompletos,
        getQuizTopicosNaoCompletos, getQuizRankPosicao, 
        getQuizEstrelasColetadas
        ]

        let roadMapInfo =[getRoadMapPorcentagem, 
            getRoadMapMateriasConcluidas,
            getRoadMapMateriasNaoConcluidas
        ]
        let gameInfo =[
            getJogoNivelAtual,
            getJogoRankPosicao
        ]

        for(let i=0; i< userInfo.length; i++){
            console.log([i])
        }
        for(let i=0; i< quizInfo.length; i++){
            console.log(quizInfo[i])
        }
        for(let i=0; i< roadMapInfo.length; i++){
            console.log(roadMapInfo[i])
        }
        for(let i=0; i< gameInfo.length; i++){
            console.log(gameInfo[i])
        }

        userInfo=null;
        quizInfo=null;
        roadMapInfo=null;
        gameInfo=null;
    }

}